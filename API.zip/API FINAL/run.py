from flask import Flask, render_template, request
import pickle
import pandas as pd
import sklearn
from sklearn.preprocessing import OrdinalEncoder,MinMaxScaler,StandardScaler,MaxAbsScaler 
from sklearn.compose import make_column_transformer
from sklearn.utils import resample
import numpy as np

app = Flask(__name__)
pred_print=""
@app.route('/',methods=['GET','POST'])
@app.route('/online_purchasing_intention')
def home():
    if request.method == 'POST':

        model = pickle.load(open('model_xgb.pkl','rb'))

        informational_duration = float(request.form.get('informational_duration'))
        product_related = int(request.form.get('product_related'))
        product_related_duration = float(request.form.get('product_related_duration'))
        bounce_rates = float(request.form.get('bounce_rates'))
        exit_rates = float(request.form.get('exit_rates'))
        page_values = float(request.form.get('page_values'))
        special_day = float(request.form.get('special_day'))
        month = int(request.form.get('month'))
        operating_systems = int(request.form.get('operating_systems'))
        browser = int(request.form.get('browser'))
        region = int(request.form.get('region'))
        traffic_type = int(request.form.get('traffic_type'))
        visitor_type = int(request.form.get('visitor_type'))
        weekend = int(request.form.get('weekend'))

        data = {'Informational_Duration':informational_duration,
                'ProductRelated':product_related,
                'ProductRelated_Duration':product_related_duration,
                'BounceRates':bounce_rates,
                'ExitRates':exit_rates,
                'PageValues':page_values,
                'SpecialDay':special_day,
                'Month':month,
                'OperatingSystems':operating_systems,
                'Browser':browser,
                'Region':region,
                'TrafficType':traffic_type,
                'VisitorType':visitor_type,
                'Weekend':weekend
    
              }  
        df = pd.DataFrame(data,index=[0])
     
    
        transformer = make_column_transformer((OrdinalEncoder(), ['Month','Browser','Region','OperatingSystems','TrafficType','VisitorType','Weekend']),remainder='passthrough')
        df = transformer.fit_transform(df)
        scaler = MaxAbsScaler()
        df = scaler.fit_transform(df)

        prediction = model.predict(df)
        
        if prediction == False:
            return render_template('online_purchasing_intention.html',pred_print="The customer will not purchase :(")
        elif prediction == True:
           return render_template('online_purchasing_intention.html',pred_print="The customer will purchase :)")
        
        
    return render_template('online_purchasing_intention.html',pred_print=" ")
        

if __name__ == '__main__':
    app.run(debug=True)
